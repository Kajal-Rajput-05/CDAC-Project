export const apiUrls = {
  Authentication: {
    SignIn: 'Auth/SignIn?',
    SignUp: 'Auth/Create',
  },
  Admin: {
    CreateStadium: 'Admin/CreateStadium',
    UpdateStadium: 'Admin/UpdateStadium',
    GetStadiumList: 'Admin/GetStadiumList',
    DeleteStadium: 'Admin/DeleteStadium',
    GetTotalEventList: 'Admin/GetTotalEventList',
  },
  Artist: {
    GetEventList: 'Artist/GetEventList',
    UpdateEvent: 'Artist/UpdateEvent',
    CreateEvent: 'Artist/CreateEvent',
    DeleteEvent: 'Artist/DeleteEvent',
    Payment: 'Artist/Payment',
    GetBookingListByArtist: 'Artist/GetBookingListByArtist',
  },
  Customer: {
    CreateBooking: 'Customer/CreateBooking',
    GetBookingListByUser: 'Customer/GetBookingListByUser',
    DeleteBooking: 'Customer/DeleteBooking',
    GetAllEventList: 'Customer/GetAllEventList',
    Payment: 'Customer/Payment',
    GetFilterEventList: 'Customer/GetFilterEventList',
  },
};
