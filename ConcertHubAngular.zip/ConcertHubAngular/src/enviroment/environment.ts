export const environment = {
    production: false,
  
    BEServer: {
      DevEnviroment: 'https://localhost:7040/api/',
    },
  };
  