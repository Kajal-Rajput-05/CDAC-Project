import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { ArtistService } from '../../services/artist.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { saveAs } from 'file-saver';
import { localStorageSession } from '../../shared/localStorage';

import { inject, TemplateRef } from '@angular/core';

import {
  ModalDismissReasons,
  NgbDatepickerModule,
  NgbModal,
} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-artisthome',
  templateUrl: './artisthome.component.html',
  styleUrl: './artisthome.component.css',
})
export class ArtisthomeComponent {
  tourLocationList: any[] = [];
  List: any[] = [];
  StadiumList: any[] = [];
  userID = 0;
  stadiumId = 0;
  ID = 0;
  IsEdit = false;
  Status = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  eventData: any;
  role = 'CASH';
  private modalService = inject(NgbModal);
  closeResult = '';

  constructor(
    public dialog: MatDialog,
    private router: Router,
    public artistService: ArtistService,
    private _snackBar: MatSnackBar,
    private _localStorage: localStorageSession
  ) {
    this.userID = Number(this._localStorage.getItem('Artist-Id'));
  }

  ngOnInit(): void {
    this.GetStadiumList();
    this.GetEventList();
  }

  GetStadiumList() {
    this.artistService.GetStadiumList().subscribe((result: any) => {
      console.log('Result : ', result);
      this.StadiumList = result;
      this.StadiumList.unshift({
        id: 0,
        name: '',
      });
      console.log('Result 1: ', this.StadiumList);
    });
  }

  GetEventList() {
    this.artistService.GetEventList(this.userID).subscribe((result: any) => {
      console.log('Result : ', result);
      this.List = result;
    });
  }

  handleDelete(id: number) {
    this.artistService.DeleteEvent(id, 'CANCELLED').subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete Event Successfully');
        this.GetStadiumList();
        this.GetEventList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleNevigateTour() {
    this.router.navigate(['/admindashboard/adminMovie/0/false']);
  }

  handleCopy(data: any) {
    this.ID = data.id;
    $('#title').val(data.title);
    $('#description').val(data.description);
    $('#location').val(data.stadium.location);
    $('#price').val(data.stadium.price);
    $('#bookingdate').val(data.bookingDate);
    $('#capacity').val(data.stadium.capacity);
    $('#stadium').val(data.stadium.id);
    this.Status = data.isActive;
    this.IsEdit = true;
    // debugger;
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, 'close', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleSubmit() {
    if (this.IsEdit) {
      this.handleEdit();
    } else {
      this.handleAdd();
    }
  }

  handleAdd() {
    console.log('Status : ', $('#status').is(':checked'));
    if (this.handleValidation()) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      userId: this.userID,
      stadiumId: this.stadiumId,
      title: $('#title').val(),
      description: $('#description').val(),
      price: Number($('#price').val()),
      location: $('#location').val(),
      capacity: Number($('#capacity').val()),
      bookingDate: $('#bookingdate').val(),
      paymentDetail: '',
    };

    this.artistService.CreateEvent(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add Event Successfully');
        this.GetStadiumList();
        this.GetEventList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleStatus(event: any) {
    console.log('Event : ', event.target.checked);
    this.Status = event.target.checked;
  }

  handleEdit() {
    if (this.handleValidation()) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      id: this.ID,
      title: $('#title').val(),
      description: $('#description').val(),
      bookingDate: $('#bookingdate').val(),
      paymentDetail: '',
    };

    this.artistService.UpdateEvent(data).subscribe({
      next: (result: any) => {
        debugger;
        console.log('Result : ', result);
        this.openSnackBar('Update Event Successfully');
        this.GetStadiumList();
        this.GetEventList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleValidation() {
    $('#titleHelp').hide();
    $('#descriptionHelp').hide();
    $('#locationHelp').hide();
    $('#priceHelp').hide();
    $('#capacityHelp').hide();
    $('#bookingdateHelp').hide();
    $('#stadiumHelp').hide();

    let Value = false;

    if (!this.IsEdit && this.stadiumId <= 0) {
      $('#stadiumHelp').show();
      Value = true;
    }

    if ($('#title').val() === '') {
      $('#titleHelp').show();
      Value = true;
    }
    if ($('#description').val() === '') {
      $('#descriptionHelp').show();
      Value = true;
    }
    if ($('#location').val() === '') {
      $('#locationHelp').show();
      Value = true;
    }
    if ($('#price').val() === '') {
      $('#priceHelp').show();
      Value = true;
    }
    if ($('#capacity').val() === '') {
      $('#capacityHelp').show();
      Value = true;
    }

    if ($('#bookingdate').val() === '') {
      $('#bookingdateHelp').show();
      Value = true;
    }

    return Value;
  }

  handleClear() {
    $('#titleHelp').hide();
    $('#descriptionHelp').hide();
    $('#locationHelp').hide();
    $('#priceHelp').hide();
    $('#capacityHelp').hide();
    $('#bookingdateHelp').hide();
    this.IsEdit = false;

    $('#title').val('');
    $('#description').val('');
    $('#location').val('');
    $('#price').val('');
    $('#capacity').val('');
    $('#bookingdate').val('');
    this.Status = false;
  }

  handleLocation(event: any) {
    console.log(event.target.value);
    const { name, value } = event.target;
    let data = this.StadiumList.filter((x) => x.id == value)[0];
    if (data !== undefined) {
      $('#location').val(data.location);
      $('#price').val(data.price);
      $('#capacity').val(data.capacity);
      this.stadiumId = data.id;
    } else {
      $('#location').val('');
      $('#price').val('');
      $('#capacity').val('');
      this.stadiumId = 0;
    }
  }

  open(content: TemplateRef<any>, item: any) {
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title' })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;
        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );

    this.eventData = item;
  }

  close() {
    $('#paymentDetailHelp').hide();
    if (this.role !== 'CASH' && $('#paymentDetail').val() === '') {
      this.openSnackBar('Please Enter Required Field');
      $('#paymentDetailHelp').show();
      return;
    }
    let data = {
      id: this.eventData.id,
      paymentType: this.role,
      paymentDetail: $('#paymentDetail').val(),
    };
    console.log('Data : ', data);

    this.artistService.Payment(data).subscribe((result: any) => {
      console.log('Result : ', result);
      this.GetEventList();
      this.modalService.dismissAll();
    });
  }

  private getDismissReason(reason: any): string {
    switch (reason) {
      case ModalDismissReasons.ESC:
        return 'by pressing ESC';
      case ModalDismissReasons.BACKDROP_CLICK:
        return 'by clicking on a backdrop';
      default:
        return `with: ${reason}`;
    }
  }
}
