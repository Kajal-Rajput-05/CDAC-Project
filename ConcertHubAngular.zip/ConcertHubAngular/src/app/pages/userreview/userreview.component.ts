import { Component } from '@angular/core';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import { AdminService } from '../../services/admin.service';

import { inject, TemplateRef } from '@angular/core';

import {
  ModalDismissReasons,
  NgbDatepickerModule,
  NgbModal,
} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-userhalllist',
  templateUrl: './userreview.component.html',
  styleUrl: './userreview.component.css',
})
export class UserReviewComponent {
  Id = 0;
  MovieID: Number = 0;
  UserID = 0;
  Status = null;
  IsDisable = true;
  List: any[] = [];
  ReceipesList: any[] = [];
  FinalList: any[] = [];
  ReceipesID = 0;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  IsEdit = false;
  private modalService = inject(NgbModal);
  closeResult = '';
  eventData: any;
  role = 'CASH';
  userID = 0;
  constructor(
    private userService: UserService,
    private _localStorage: localStorageSession,
    private _snackBar: MatSnackBar
  ) {
    this.userID = this._localStorage.getItem('Customer-Id');
  }

  ngOnInit() {
    this.GetBookingListByUser();
  }

  GetBookingListByUser() {
    this.userService.GetBookingListByUser(this.userID).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleBookTicket(data: any) {}

  handleValidation() {
    $('#locationNameHelp').hide();
    $('#locationImageUrlHelp').hide();
    $('#confirmPasswordHelp').hide();
    let value = true;
    console.log('locationName : ', $('#locationName').val());

    if ($('#locationName').val() === '') {
      $('#locationNameHelp').show();
      value = false;
    }

    console.log('locationImageUrl : ', $('#locationImageUrl').val());
    if ($('#locationImageUrl').val() === '') {
      $('#locationImageUrlHelp').show();
      value = false;
    }

    console.log('costOfTravel : ', $('#costOfTravel').val());
    if ($('#costOfTravel').val() === '') {
      $('#costOfTravelHelp').show();
      value = false;
    }

    return value;
  }

  handleEditComment(data: any) {
    $('#comment').val(data.comment);
    $('#status').val(data.status);
    $('#receipName').text(data.receipeName);
    this.ReceipesID = data.receipeId;
    this.IsEdit = true;
    this.Id = data.id;
    this.IsDisable = false;
    // debugger;
  }

  handleDeleteComment(id: any) {
    // this.serviceService.DeleteUserReview(id).subscribe({
    //   next: (result: any) => {
    //     console.log('Result : ', result);
    //     this.openSnackBar('Delete Review Successfully');
    //     this.GetUserReviewList();
    //   },
    //   error: (error: any) => {
    //     console.log('Error : ', error);
    //     this.openSnackBar('Something Went wrong');
    //   },
    // });
  }

  handleStatus(status: any) {
    this.Status = status;
    $('#status').val(status ? 'LIKE' : 'UNLIKE');
  }

  handleSubmit() {
    this.handleEdit();
  }

  handleEdit() {
    $('#commentHelp').hide();
    let Value = false;
    if ($('#comment').val() === '') {
      $('#commentHelp').show();
      Value = true;
    }

    if (Value) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      id: this.Id,
      comment: $('#comment').val(),
      status: $('#status').val(),

      createdDate: new Date(),
      receipeId: this.ReceipesID,
      userId: this.UserID,
    };
    // this.serviceService.UpdateUserReview(data).subscribe({
    //   next: (result: any) => {
    //     console.log('Result : ', result);
    //     this.openSnackBar('Update Review Successfully');
    //     this.GetUserReviewList();
    //     this.handleClear();
    //   },
    //   error: (error: any) => {
    //     console.log('Error : ', error);
    //     this.openSnackBar('Something Went wrong');
    //   },
    // });
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, 'close', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleClear() {
    $('#comment').val('');
    $('#status').val('');

    this.IsEdit = false;
    this.Id = 0;
    this.IsDisable = true;
  }

  close() {
    $('#paymentDetailHelp').hide();
    if (this.role !== 'CASH' && $('#paymentDetail').val() === '') {
      this.openSnackBar('Please Enter Required Field');
      $('#paymentDetailHelp').show();
      return;
    }
    let data = {
      id: this.eventData.id,
      paymentType: this.role,
      paymentDetail: $('#paymentDetail').val(),
    };
    console.log('Data : ', data);

    this.userService.Payment(data).subscribe((result: any) => {
      console.log('Result : ', result);
      this.GetBookingListByUser();
      this.modalService.dismissAll();
    });
  }

  open(content: TemplateRef<any>, item: any) {
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title' })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;
        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );

    this.eventData = item;
  }

  private getDismissReason(reason: any): string {
    switch (reason) {
      case ModalDismissReasons.ESC:
        return 'by pressing ESC';
      case ModalDismissReasons.BACKDROP_CLICK:
        return 'by clicking on a backdrop';
      default:
        return `with: ${reason}`;
    }
  }
}
