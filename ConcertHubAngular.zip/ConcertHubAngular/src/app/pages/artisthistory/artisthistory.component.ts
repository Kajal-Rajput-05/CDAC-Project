import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ArtistService } from '../../services/artist.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { localStorageSession } from '../../shared/localStorage';

@Component({
  selector: 'app-artisthistory',
  templateUrl: './artisthistory.component.html',
  styleUrl: './artisthistory.component.css',
})
export class ArtisthistoryComponent {
  List: any[] = [];
  userID = 0;
  constructor(
    public dialog: MatDialog,
    private router: Router,
    public artistService: ArtistService,
    private _snackBar: MatSnackBar,
    private _localStorage: localStorageSession
  ) {
    this.userID = Number(this._localStorage.getItem('Artist-Id'));
  }

  ngOnInit(): void {
    debugger;
    this.GetBookingListByArtist();
  }

  GetBookingListByArtist() {
    this.artistService
      .GetBookingListByArtist(this.userID)
      .subscribe((result: any) => {
        console.log('Result : ', result);
        this.List = result;
      });
  }
}
