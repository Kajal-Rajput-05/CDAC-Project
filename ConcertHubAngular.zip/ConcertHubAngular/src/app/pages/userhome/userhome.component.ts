import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { saveAs } from 'file-saver';
import { ReceipeinfodialogComponent } from '../receipeinfodialog/receipeinfodialog.component';
@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrl: './userhome.component.css',
})
export class UserhomeComponent {
  tourLocationList: any[] = [];
  List: any[] = [];
  userID = 0;
  ID = 0;
  IsEdit = false;
  Price = 0;
  Capacity = 0;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    public dialog: MatDialog,
    private router: Router,
    public serviceService: UserService,
    private businessService: AdminService,
    private _localStorage: localStorageSession,
    private _snackBar: MatSnackBar
  ) {
    this.userID = this._localStorage.getItem('Customer-Id');
  }

  ngOnInit(): void {
    this.GetAllEventList();
  }

  GetAllEventList() {
    this.serviceService.GetAllEventList().subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  GetFilterEventList(data: any) {
    this.serviceService.GetFilterEventList(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleBookTicket(data: any) {
    this.ID = data.id;
    $('#name').text(data.title);
    $('#description').text(data.description);
    $('#location').text(data.stadium.location);
    $('#eventDate').text(data.bookingDate);
    $('#capacity').text(data.capacity);
    $('#price').text(data.stadium.price);
    this.Price = data.stadium.price;
    this.IsEdit = true;
    this.Capacity = data.capacity;
  }

  handleChange(event: any) {
    const { name, value } = event.target;
    console.log(this.Capacity + ' ' + value);

    if (value > this.Capacity || value <= 0) {
      $('#quantityHelp').show();
    } else {
      $('#price').text();
      $('#quantityHelp').hide();
    }
  }

  handleSubmit() {
    $('#quantityHelp').hide();
    if ($('#quantity').val() === '') {
      $('#quantityHelp').show();
      return;
    }

    if (Number($('#quantity').val()) <= 0) {
      $('#quantityHelp').show();
      return;
    } else if (Number($('#quantity').val()) > this.Capacity) {
      $('#quantityHelp').show();
      return;
    }

    let data = {
      userId: this.userID,
      eventId: this.ID,
      quentity: Number($('#quantity').val()),
      totalPrice: Number($('#quantity').val()) * this.Price,
    };
    console.log('Data : ', data);

    this.serviceService.CreateBooking(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add Booking Successfully');
        this.IsEdit = false;
        this.handleClear();
        this.GetAllEventList();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleCategorySearch() {
    if ($('#category').val() === '') {
      this.GetAllEventList();
      return;
    }

    this.GetFilterEventList($('#category').val());

    // this.serviceService.GetReceipesByCategory($('#category').val()).subscribe({
    //   next: (result: any) => {
    //     console.log('Result : ', result);
    //     this.List = result;
    //   },
    //   error: (error: any) => {
    //     console.log('Error : ', error);
    //     this.openSnackBar('Something went wrong');
    //   },
    // });
  }

  handleSearchClear() {
    $('#category').val('');
    this.GetAllEventList();
  }

  handleSearch() {
    if ($('#keyword').val() === '') {
      this.GetAllEventList();
      return;
    }

    // this.serviceService.GetReceipesByKeyword($('#keyword').val()).subscribe({
    //   next: (result: any) => {
    //     console.log('Result : ', result);
    //     this.List = result;
    //   },
    //   error: (error: any) => {
    //     console.log('Error : ', error);
    //     this.openSnackBar('Something went wrong');
    //   },
    // });
  }

  handleClear() {
    $('#commentHelp').hide();
    this.IsEdit = false;

    $('#name').text('');
    $('#description').text('');
    $('#location').text('');
    $('#eventDate').text('');
    $('#capacity').text('');
    $('#price').text('');
    $('#quantity').val('');
  }
}
