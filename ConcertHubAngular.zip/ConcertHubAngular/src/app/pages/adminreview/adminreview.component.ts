import { Component } from '@angular/core';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import { AdminService } from '../../services/admin.service';
import { ArtistService } from '../../services/artist.service';
@Component({
  selector: 'app-adminhalllist',
  templateUrl: './adminreview.component.html',
  styleUrl: './adminreview.component.css',
})
export class AdminReviewComponent {
  List: any[] = [];
  userID = 0;

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    private _localStorage: localStorageSession,
    private _snackBar: MatSnackBar,
    public artistService: ArtistService,
    public adminService: AdminService,
  ) {
    this.userID = Number(this._localStorage.getItem('Artist-Id'));
  }

  ngOnInit(): void {
    this.GetEventList();
  }

  GetEventList() {
    this.adminService.GetTotalEventList().subscribe((result: any) => {
      console.log('Result : ', result);
      this.List = result;
    });
  }

  handleChangeStatus(id: any, Status: string) {
    this.artistService.DeleteEvent(id, Status).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete Event Successfully');
        this.GetEventList();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }
}
