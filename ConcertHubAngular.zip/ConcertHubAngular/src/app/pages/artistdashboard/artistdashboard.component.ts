import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { localStorageSession } from '../../shared/localStorage';

@Component({
  selector: 'app-artistdashboard',
  templateUrl: './artistdashboard.component.html',
  styleUrl: './artistdashboard.component.css',
})
export class ArtistdashboardComponent {
  UserName = '';
  constructor(
    private router: Router,
    private _localStorage: localStorageSession
  ) {
    this.UserName = this._localStorage.getItem('Artist-Email');
  }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    if (this._localStorage.getItem('Artist-Token') === null) {
      this.router.navigate(['/signIn']);
    }
  }

  handleHomeNav() {
    console.log('Navigate To Home');
    this.router.navigate(['/artistdashboard/home']);
  }

  handleNavSignOut() {
    console.log('Navigate To SignOut');
    this._localStorage.removeItem('Artist-Id');
    this._localStorage.removeItem('Artist-Token');
    this._localStorage.removeItem('Artist-Email');
    this.router.navigate(['/signIn']);
  }

  handleTheatersNav() {
    debugger;
    this.router.navigate(['/artistdashboard/history']);
  }
}
