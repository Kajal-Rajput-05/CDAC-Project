import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';
import { AdmindashboardComponent } from './pages/admindashboard/admindashboard.component';
import { UserdashboardComponent } from './pages/userdashboard/userdashboard.component';
import { AdminhomeComponent } from './pages/adminhome/adminhome.component';
import { UserhomeComponent } from './pages/userhome/userhome.component';
import { GreetingComponent } from './pages/greetingpage/greeting.component';
import { WelcomepageComponent } from './pages/welcomepage/welcomepage.component';
import { AdminReviewComponent } from './pages/adminreview/adminreview.component';
import { UserReviewComponent } from './pages/userreview/userreview.component';
import { ArtistdashboardComponent } from './pages/artistdashboard/artistdashboard.component';
import { ArtisthomeComponent } from './pages/artisthome/artisthome.component';
import { ArtisthistoryComponent } from './pages/artisthistory/artisthistory.component';

const routes: Routes = [
  {
    path: '',
    component: WelcomepageComponent, //
  },
  {
    path: 'signIn',
    component: SigninComponent, //
  },
  {
    path: 'signup',
    component: SignupComponent, //
  },
  {
    path: 'admindashboard',
    component: AdmindashboardComponent,
    children: [
      {
        path: 'home',
        component: AdminhomeComponent, //
      },
      {
        path: 'adminreview', //
        component: AdminReviewComponent,
      },
    ],
  },
  {
    path: 'userdashboard',
    component: UserdashboardComponent,
    children: [
      {
        path: 'home', //
        component: UserhomeComponent,
      },
      {
        path: 'greeting',
        component: GreetingComponent, //
      },
      {
        path: 'review', //
        component: UserReviewComponent,
      },
    ],
  },
  {
    path: 'artistdashboard',
    component: ArtistdashboardComponent,
    children: [
      {
        path: 'home', //
        component: ArtisthomeComponent,
      },
      {
        path: 'history', //
        component: ArtisthistoryComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
