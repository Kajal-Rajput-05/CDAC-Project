import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
import { localStorageSession } from '../shared/localStorage';
const _baseUrl = environment.BEServer.DevEnviroment;
const _apiUrl = apiUrls.Customer;

// const _authToken = localStorage.getItem('Admin-Token');

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(
    private _httpClient: HttpClient,
    private _localStorage: localStorageSession
  ) {}

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${this._localStorage.getItem('Customer-Token')}`,
  });

  GetAllEventList() {
    return this._httpClient.get(_baseUrl + _apiUrl.GetAllEventList, {
      headers: this.headers,
    });
  }

  CreateBooking(data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.CreateBooking, data, {
      headers: this.headers,
    });
  }

  GetBookingListByUser(_data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.GetBookingListByUser + '?UserId=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  GetFilterEventList(_data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.GetFilterEventList + '?artistType=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  DeleteBooking() {
    return this._httpClient.delete(_baseUrl + _apiUrl.DeleteBooking, {
      headers: this.headers,
    });
  }

  Payment(_data: any) {
    return this._httpClient.patch(
      _baseUrl +
        _apiUrl.Payment +
        '?id=' +
        _data.id +
        '&paymentType=' +
        _data.paymentType,
      _data,
      {
        headers: this.headers,
      }
    );
  }
}
