import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';

// import { apiUrls } from 'src/enviroment/apiUrls';
import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
const _baseUrl = environment.BEServer.DevEnviroment;
const _apiUrl = apiUrls.Authentication;
@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    // 'Authorization': `Bearer ${_authToken}`
  });

  constructor(private _httpClient: HttpClient) {}

  SignIn(_data: any) {
    return this._httpClient.get(
      _baseUrl +
        _apiUrl.SignIn +
        'EmailId=' +
        _data.email +
        '&Password=' +
        _data.password,
      {
        headers: this.headers,
      }
    );
  }

  SignUp(_data: any) {
    return this._httpClient.post<any>(_baseUrl + _apiUrl.SignUp, _data, {
      headers: this.headers,
    });
  }
}
