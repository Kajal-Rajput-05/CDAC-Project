import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
import { localStorageSession } from '../shared/localStorage';
const _baseUrl = environment.BEServer.DevEnviroment;
const _artistApiUrl = apiUrls.Artist;
const _adminApiUrl = apiUrls.Admin;

@Injectable({
  providedIn: 'root',
})
export class ArtistService {
  constructor(
    private _httpClient: HttpClient,
    private _localStorage: localStorageSession
  ) {}

  jsonheaders = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${this._localStorage.getItem('Artist-Token')}`,
  });

  GetStadiumList() {
    return this._httpClient.get(_baseUrl + _adminApiUrl.GetStadiumList, {
      headers: this.jsonheaders,
    });
  }

  CreateEvent(_data: any) {
    return this._httpClient.post(_baseUrl + _artistApiUrl.CreateEvent, _data, {
      headers: this.jsonheaders,
    });
  }

  GetEventList(UserID: Number) {
    return this._httpClient.get(
      _baseUrl + _artistApiUrl.GetEventList + '?UserId=' + UserID,
      {
        headers: this.jsonheaders,
      }
    );
  }

  GetBookingListByArtist(UserID: Number) {
    return this._httpClient.get(
      _baseUrl + _artistApiUrl.GetBookingListByArtist + '?UserId=' + UserID,
      {
        headers: this.jsonheaders,
      }
    );
  }

  UpdateEvent(_data: any) {
    return this._httpClient.put(_baseUrl + _artistApiUrl.UpdateEvent, _data, {
      headers: this.jsonheaders,
    });
  }

  DeleteEvent(_id: any, status: string) {
    return this._httpClient.delete(
      _baseUrl + _artistApiUrl.DeleteEvent + '?Id=' + _id + '&Status=' + status,
      {
        headers: this.jsonheaders,
      }
    );
  }

  Payment(_data: any) {
    //https://localhost:7040/api/Artist/Payment?id=0&paymentType=CASH&paymentDetail=124

    return this._httpClient.patch(
      _baseUrl +
        _artistApiUrl.Payment +
        '?id=' +
        _data.id +
        '&paymentType=' +
        _data.paymentType +
        '&paymentDetail=' +
        _data.paymentDetail,
      _data,
      {
        headers: this.jsonheaders,
      }
    );
  }
}
