import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
import { localStorageSession } from '../shared/localStorage';
const _baseUrl = environment.BEServer.DevEnviroment;
const _apiUrl = apiUrls.Admin;
const _artistApiUrl = apiUrls.Artist;
// const _authToken = localStorage.getItem('Admin-Token');

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(
    private _httpClient: HttpClient,
    private _localStorage: localStorageSession
  ) {}

  jsonheaders = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${this._localStorage.getItem('Admin-Token')}`,
  });

  multipartheaders = new HttpHeaders({
    // 'Content-Type': 'multipart/form-data',
    Authorization: `Bearer ${this._localStorage.getItem('Admin-Token')}`,
  });

  // 'Content-Type', 'text/plain'
  CreateStadium(_data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.CreateStadium, _data, {
      headers: this.jsonheaders,
    });
  }

  UpdateStadium(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.UpdateStadium, _data, {
      headers: this.jsonheaders,
    });
  }

  GetStadiumList() {
    return this._httpClient.get(_baseUrl + _apiUrl.GetStadiumList, {
      headers: this.jsonheaders,
    });
  }

  GetTotalEventList() {
    return this._httpClient.get(_baseUrl + _apiUrl.GetTotalEventList, {
      headers: this.jsonheaders,
    });
  }

  DeleteStadium(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.DeleteStadium + '?Id=' + _data,
      {
        headers: this.jsonheaders,
      }
    );
  }

  DeleteEvent(_id: any, status: string) {
    return this._httpClient.delete(
      _baseUrl + _artistApiUrl.DeleteEvent + '?Id=' + _id + '&Status=' + status,
      {
        headers: this.jsonheaders,
      }
    );
  }
}
